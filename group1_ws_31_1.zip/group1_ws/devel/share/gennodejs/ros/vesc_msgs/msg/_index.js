
"use strict";

let VescState = require('./VescState.js');
let VescStateStamped = require('./VescStateStamped.js');

module.exports = {
  VescState: VescState,
  VescStateStamped: VescStateStamped,
};


"use strict";

let scan_range = require('./scan_range.js');

module.exports = {
  scan_range: scan_range,
};

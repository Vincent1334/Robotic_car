sudo TRACE=ON python setup.py install

sudo python setup.py install

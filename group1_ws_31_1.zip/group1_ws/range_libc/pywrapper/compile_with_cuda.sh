sudo WITH_CUDA=ON python setup.py install

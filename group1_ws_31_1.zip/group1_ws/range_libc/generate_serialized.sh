# ./bin/range_lib --method="pcddt" --map_path=../maps/synthetic.map.png --cddt_save_path=../tmp/synthetic/pcddt.json
# ./bin/range_lib --method="cddt" --map_path=../maps/synthetic.map.png --cddt_save_path=../tmp/synthetic/cddt.json
# ./bin/range_lib --method="pcddt" --map_path=../maps/basement_hallways_5cm.png --cddt_save_path=../tmp/basement/pcddt.json
# ./bin/range_lib --method="cddt" --map_path=../maps/basement_hallways_5cm.png --cddt_save_path=../tmp/basement/cddt.json


./bin/range_lib --method="cddt" --map_path=../maps/basement_hallways_5cm.png --log_path=../tmp/basement/trial1/
./bin/range_lib --method="cddt" --map_path=../maps/basement_hallways_5cm.png --log_path=../tmp/basement/trial2/
./bin/range_lib --method="cddt" --map_path=../maps/basement_hallways_5cm.png --log_path=../tmp/basement/trial3/
./bin/range_lib --method="cddt" --map_path=../maps/basement_hallways_5cm.png --log_path=../tmp/basement/trial4/
./bin/range_lib --method="cddt" --map_path=../maps/basement_hallways_5cm.png --log_path=../tmp/basement/trial5/
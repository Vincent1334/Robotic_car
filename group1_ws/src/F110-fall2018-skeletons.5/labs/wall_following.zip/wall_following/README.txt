This is code in order to do a simple wall following in the simulator. Because
it depends on code from other git repositories (using instructions from the
reference manual to set up the simulator), this repository will only contain the
/launch, /msg, and /scripts folders. If we had a workspace, the contents of this 
repository would go into workspace/src/[folder_name]/wall_following. 
